Basic-shopping-cart-application-using-spring-mvc-and-hibernate

Functionalities implemeted:

-> User authentication and User Authorization

->Two sections:-> User Section,Admin Section

Admin Section:

-> Add/Edit/Delete category

-> Add/edit/Delete items to Category

User Section:

->View All the items

->Filter items based on category

->Add items to card and add billable details

->Generate billable details,total cart details and cost.
